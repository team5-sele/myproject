import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class titlereport {
  @Test
  public void f() {
	  
	  System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
	  WebDriver driver=new ChromeDriver();
	  driver.get("http://examples.codecharge.com/TaskManager/Default.php");
	  String s=driver.getTitle();
	  System.out.println(s);
  }
  WebDriver driver;
	@Given("^open chrome and start application$")
	public void open_chrome_and_start_application() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		System.out.println("browser is launched");
	   
	}

	@When("^the user click in the adminstration link$")
	public void the_user_click_in_the_adminstration_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    driver.findElement(By.xpath("/html/body/table[1]/tbody/tr[2]/td[3]/a/img")).click();
	}

	@Then("^the user enter his crediantials and login to the administration page$")
	public void the_user_enter_his_crediantials_and_login_to_the_administration_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
		driver.findElement(By.name("login")).sendKeys("admin");
		driver.findElement(By.name(" password")).sendKeys("admin");
		driver.findElement(By.name("DoLogin")).click();
	}


}
