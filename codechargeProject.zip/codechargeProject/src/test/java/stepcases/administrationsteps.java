package stepcases;

import java.io.File;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.administrationpage;

public class administrationsteps {
	
    
	administrationpage b=new administrationpage();
	
	
	@Given("^open administration page and start add details$")
	public void open_administration_page_and_start_add_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.get("http://examples.codecharge.com/TaskManager/Default.php");
	
		  String s=driver.getTitle();
		  administrationpage.Logger("homepage is opened");
		  System.out.println(s);
	}
	
	


	@When("^the user click in the employee  link$")
	public void the_user_click_in_the_employee_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   b.Click();
	   administrationpage.Logger("user enter the username and password ");
	   b.Enter();
	   administrationpage.Logger(" user enter into administation page succesfully to fill up the details");
	}

@Then("^the user enter his details and click add and set the priority$")
public void the_user_enter_his_details_and_click_add_and_set_the_priority() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    b.Clickk();
    administrationpage.Logger(" user enters the details in administration page in successfully");
    
}


	
	

}
