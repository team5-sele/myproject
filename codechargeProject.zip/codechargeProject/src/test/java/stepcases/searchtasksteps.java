package stepcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.searchtaskpage;

public class searchtasksteps {
	
	searchtaskpage d= new searchtaskpage();
	@Given("^open application and start search$")
	public void open_application_and_start_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.get("http://examples.codecharge.com/TaskManager/Default.php");
		  String s=driver.getTitle();
		  System.out.println(s);
		
	}

	@When("^the user start to search and give details for searching$")
	public void the_user_start_to_search_and_give_details_for_searching() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    d.Click();
	}

	@Then("^the user enter search$")
	public void the_user_enter_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  d.search();
	}



}
