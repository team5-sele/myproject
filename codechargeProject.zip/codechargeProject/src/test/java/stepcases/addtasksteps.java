package stepcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import pages.addtaskpage;

public class addtasksteps {
	
	addtaskpage  c=new addtaskpage();
	
	@Given("^Open add task page$")
	public void open_add_task_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
		  WebDriver driver=new ChromeDriver();
		  driver.get("http://examples.codecharge.com/TaskManager/Default.php");
		  String s=driver.getTitle();
		  System.out.println(s);
		  
		  
		
		
	}

	@Then("^fill the details$")
	public void fill_the_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		c.Click();
	   c.fill();
	}

	@Then("^Then click add$")
	public void then_click_add() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  c.add();
	}



}
