package stepcases;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.addnewprojectpage;

public class addnewsteps {
	  addnewprojectpage p=new addnewprojectpage();
	@Given("^open administration page and start add new project$")
	public void open_administration_page_and_start_add_new_project() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	  p.Click();
	  addnewprojectpage.Logger("browser launced succesflly to add new project");
	}

	@When("^the user click in the project link$")
	public void the_user_click_in_the_project_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    p.Enter();
	    addnewprojectpage.Logger("to add a project user click a add new project"); 
	}

	@Then("^the user select add new project and start to add a project$")
	public void the_user_select_add_new_project_and_start_to_add_a_project() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    p.clickk();
	    addnewprojectpage.Logger("new project is added sucessfully");
	}



}
