package pages;

import java.io.File;
import java.io.IOException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class addtaskpage {
	
	WebDriver driver;
    static int i=1;
@Test
	public void Click() throws IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
		driver=new ChromeDriver();
	driver.get("http://examples.codecharge.com/TaskManager/TaskRecord.php");
	takeSnap();
	
		
	}
	
	public void fill() throws IOException, InterruptedException {
		

		driver.findElement(By.name("login")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin");
		driver.findElement(By.name("DoLogin")).click();
		takeSnap();
		driver.findElement(By.name("task_name")).sendKeys("payment");
		driver.findElement(By.name("task_desc")).sendKeys("payment is failed while by using debit card");
		takeSnap();
		
		WebElement comboBox=driver.findElement(By.name("project_id"));
		Select selection =new Select(comboBox);
		selection.selectByIndex(0);
		selection.selectByVisibleText("CodeCharge");
		takeSnap();

		WebElement comboBox1=driver.findElement(By.name("priority_id"));
		Select selection1 =new Select(comboBox1);
		selection1.selectByIndex(0);
		selection1.selectByVisibleText("High");
		takeSnap();

		WebElement comboBox11=driver.findElement(By.name("status_id"));
		Select selection11 =new Select(comboBox11);
		selection11.selectByIndex(0);
		selection11.selectByVisibleText("Closed");
		takeSnap();

		WebElement comboBox111=driver.findElement(By.name("type_id"));
		Select selection111 =new Select(comboBox111);
		selection111.selectByIndex(3);
		selection111.selectByVisibleText("Task");
		takeSnap();

		WebElement comboBox1111=driver.findElement(By.name("user_id_assign_to"));
		Select selection1111 =new Select(comboBox1111);
		selection1111.selectByIndex(10);
		selection1111.selectByVisibleText("Conrad Murphy");
		takeSnap();
		
	
	        //start date	
			Actions action=new Actions(driver);
			action.moveToElement(driver.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/form/table[2]/tbody/tr[8]/td/a/img"))).click().build().perform();
			String parent=driver.getWindowHandle();
			System.out.println(parent);
			Set<String>allWindows=driver.getWindowHandles();
			for(String Window:allWindows)
			{
				System.out.println(Window);
				if(!parent.equalsIgnoreCase(Window))
				{
					driver.switchTo().window(Window);
				}
			}
		
			Actions actions=new Actions(driver);
			actions.moveToElement(driver.findElement(By.xpath("/html/body/center/table/tbody/tr/td/table/tbody/tr[4]/td[3]/a"))).click().build().perform();
			driver.switchTo().window(parent);
		
			takeSnap();
	
		  //end date
			Actions action1=new Actions(driver);
			action1.moveToElement(driver.findElement(By.xpath("/html/body/table[2]/tbody/tr/td/form/table[2]/tbody/tr[9]/td/a/img"))).click().build().perform();
			String parent1=driver.getWindowHandle();
			System.out.println(parent1);
			Set<String>allWindows1=driver.getWindowHandles();
			for(String Window:allWindows1)
			{
				System.out.println(Window);
				if(!parent1.equalsIgnoreCase(Window))
				{
					driver.switchTo().window(Window);
				}
			}
			Actions actions1=new Actions(driver);
			actions1.moveToElement(driver.findElement(By.xpath("/html/body/center/table/tbody/tr/td/table/tbody/tr[5]/td[6]/a"))).click().build().perform();
			driver.switchTo().window(parent1);
			
			Thread.sleep(2000);
			
			//extent reports
			ExtentReports extent;
			ExtentTest logger;
			extent=new ExtentReports("D:\\cts programs\\codechargeProject\\src\\test\\resources\\extentReport1.html",true);
			
			logger=extent.startTest("add task page Test");
			logger.log(LogStatus.PASS," add task Test is success");
			System.out.println(" add task Test in sucess");
			extent.flush();
			extent.endTest(logger);
			extent.close();
		}
		
		
		public void add() throws IOException {
			
			driver.findElement(By.name("Insert")).click();
			takeSnap();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			
		}
		
		
		public  void takeSnap() throws IOException {
			
			File srcFile;
			srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			Files.copy(srcFile, new File("D:\\cts programs\\codechargeProject\\screenshort\\taskscreenshots" + i + ".png"));
			i++;
			
		}
		
	}


