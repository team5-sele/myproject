package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import stepcases.administrationsteps;

public class administrationpage {
	
	static WebDriver driver;
	static int i=1;
	
		
	
		public void Enter()
		{
	

	   driver.findElement(By.name("login")).sendKeys("admin");
		
		driver.findElement(By.name("password")).sendKeys("admin");
		
			
		driver.findElement(By.name("DoLogin")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.linkText("Employees")).click();
	
		}



		public void Click() throws IOException {
			// TODO Auto-generated method stub

			System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
		takeSnap();
	
		
	
		}
		public void Clickk() throws InterruptedException, IOException {
			
			driver.findElement(By.linkText("Add New Employee")).click();
			takeSnap();
	
			driver.findElement(By.name("full_name")).sendKeys("jessica");
			driver.findElement(By.name("email")).sendKeys("jessica@gmail.com");
			driver.findElement(By.name("login")).sendKeys("user");
			driver.findElement(By.name("password")).sendKeys("user");
			WebElement comboBox=driver.findElement(By.name("security_group_id"));
			Select selection =new Select(comboBox);
			selection.selectByIndex(1);
			selection.selectByVisibleText("User");
			takeSnap();
		    Thread.sleep(2000);
			
			
			driver.findElement(By.name("Insert")).click();
			takeSnap();

			driver.findElement(By.linkText("Next")).click();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			takeSnap();
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			
			driver.findElement(By.linkText("Priorities")).click();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			takeSnap();
			
			driver.findElement(By.linkText("High")).click();
			driver.findElement(By.name("Update")).click();
		    Thread.sleep(2000);
			takeSnap();
			
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			
			driver.findElement(By.linkText("Projects")).click();
			takeSnap();
			
			driver.findElement(By.linkText("CodeCharge")).click();
			driver.findElement(By.name("Update")).click();
		    Thread.sleep(2000);
			takeSnap();
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			
			driver.findElement(By.linkText("Statuses")).click();
			takeSnap();
			
			driver.findElement(By.linkText("Closed")).click();
			driver.findElement(By.name("Update")).click();
			takeSnap();
			Thread.sleep(2000);
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			
			
			driver.findElement(By.linkText("Types")).click();
			takeSnap();
			
			driver.findElement(By.linkText("Task")).click();
			driver.findElement(By.name("Update1")).click();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
			takeSnap();
			Thread.sleep(2000);
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			driver.get("http://examples.codecharge.com/TaskManager/Default.php");
			
			
			ExtentReports extent;
			ExtentTest logger;
			extent=new ExtentReports("D:\\cts programs\\codechargeProject\\src\\test\\resources\\extentReport.html",true);
			
			logger=extent.startTest("Adminisration page Test");
			logger.log(LogStatus.PASS,"Test is success");
			System.out.println("Test in sucess");
			extent.flush();
			extent.endTest(logger);
			extent.close();
			
			
			
			
		}
		
		
		
		
		public  void takeSnap() throws IOException {
			
			File srcFile;
			srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			Files.copy(srcFile, new File("D:\\cts programs\\codechargeProject\\screenshort\\taskscreenshots" + i + ".png"));
			i++;
			
		}
		
		public static void Logger(String msg) {
			Logger lo=Logger.getLogger(administrationsteps.class.getName());
			lo.setLevel(Level.ALL);
			lo.info(msg);
		
		
}
}
