package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import stepcases.addnewsteps;

public class addnewprojectpage {

	
	static WebDriver driver;
	static int i=1;
	
		
	
		public void Enter() throws IOException
		{
	

	   driver.findElement(By.name("login")).sendKeys("admin");
		
		driver.findElement(By.name("password")).sendKeys("admin");
		
			
		driver.findElement(By.name("DoLogin")).click();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.linkText("Projects")).click();
	    takeSnap();
		}



		public void Click() throws IOException {
			// TODO Auto-generated method stub

			System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
			driver=new ChromeDriver();
		driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
	
		
	
       }
		
		
		public void clickk() throws IOException {
			
			driver.findElement(By.linkText("Add New Project")).click();
			driver.findElement(By.name("project_name")).sendKeys("Cognizant");
			takeSnap();
			driver.findElement(By.name("Insert")).click();
			takeSnap();
			driver.get("http://examples.codecharge.com/TaskManager/Administration.php");
			
			
			ExtentReports extent;
			ExtentTest logger;
			extent=new ExtentReports("D:\\cts programs\\codechargeProject\\src\\test\\resources\\extentReport3.html",true);
			
			logger=extent.startTest("Add a new project test");
			logger.log(LogStatus.PASS,"Test is success");
			System.out.println("Test in sucess");
			extent.flush();
			extent.endTest(logger);
			extent.close();
			
			
		}


		public  void takeSnap() throws IOException {
			
			File srcFile;
			srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			Files.copy(srcFile, new File("D:\\cts programs\\codechargeProject\\screenshort\\taskscreenshots" + i + ".png"));
			i++;
		}
		public static void Logger(String msg) {
			Logger lo=Logger.getLogger(addnewsteps.class.getName());
			lo.setLevel(Level.ALL);
			lo.info(msg);
		
		
}
		
}
