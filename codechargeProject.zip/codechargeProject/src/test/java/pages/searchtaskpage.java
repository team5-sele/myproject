package pages;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.google.common.io.Files;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class searchtaskpage {

	
	WebDriver driver;
	static int i=1;

	public void Click() throws IOException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "D:\\CTS chennai selenium setup files\\chromedriver_win32 (2)\\chromedriver.exe");
		driver=new ChromeDriver();
	driver.get("http://examples.codecharge.com/TaskManager/Default.php");
	takeSnap();
	WebElement comboBox=driver.findElement(By.name("assign_to"));
	Select selection =new Select(comboBox);
	selection.selectByIndex(0);
	selection.selectByVisibleText("Alex Antion");
    takeSnap();
     
	WebElement comboBox1=driver.findElement(By.name("project_id"));
	Select selection1 =new Select(comboBox1);
	selection1.selectByIndex(0);
	selection1.selectByVisibleText("CodeCharge");
    takeSnap();
	

	WebElement comboBox11=driver.findElement(By.name("priority_id"));
	Select selection11 =new Select(comboBox11);
	selection11.selectByIndex(0);
	selection11.selectByVisibleText("High");
   takeSnap();
	
	

	WebElement comboBox111=driver.findElement(By.name("status_id"));
	Select selection111 =new Select(comboBox111);
	selection111.selectByIndex(0);
	selection111.selectByVisibleText("Closed");
	takeSnap();
	
	WebElement comboBox1111=driver.findElement(By.name("type_id"));
	Select selection1111 =new Select(comboBox1111);
	selection1111.selectByIndex(0);
	selection1111.selectByVisibleText("Bug");
   takeSnap();
   driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	}
	
	
	public void search() throws IOException {
		
		
		driver.findElement(By.name("DoSearch")).click();
		takeSnap();
		driver.quit();
		
		ExtentReports extent;
		ExtentTest logger;
		extent=new ExtentReports("D:\\cts programs\\codechargeProject\\src\\test\\resources\\extentReport2.html",true);
		
		logger=extent.startTest("search page Test");
		logger.log(LogStatus.PASS," search Test is success");
		System.out.println(" search Test in sucess");
		extent.flush();
		extent.endTest(logger);
		extent.close();
	}
	
	public  void takeSnap() throws IOException {
		
		File srcFile;
		srcFile=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(srcFile, new File("D:\\cts programs\\codechargeProject\\screenshort\\taskscreenshots" + i + ".png"));
		i++;
		
	}
}
